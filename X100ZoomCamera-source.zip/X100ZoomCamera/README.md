# X100 Zoom Camera — experimental direct-HAL build

Purpose: test whether a Vivo X100 can record 3840×2160 at 60 fps while requesting zoom ratios above the stock Camera app's 10× video UI cap.

## Important
This is a separate app (`com.anas.x100zoom`). It does **not** replace or patch Vivo's signed system Camera APK.

The app deliberately distinguishes between:
- **DIRECT** zoom: Camera2/HAL accepted the requested zoom ratio.
- **HAL limit**: the device-reported Camera2 range is lower than the requested zoom.

No fake 10×→30× upscaling is used in this first build. If the X100 exposes ≥30× to Camera2 in the 4K60 session, the direct path is the cleanest way to bypass Vivo's stock-app 10× policy while retaining OEM stabilization/lens switching handled by the HAL.

## Recording configuration
- 3840×2160
- 60 fps target
- HEVC/H.265 when an encoder is available, H.264 fallback
- 100 Mbps video bitrate
- AAC 48 kHz / 192 kbps audio
- Continuous video AF
- Best available stabilization: preview stabilization → EIS → OIS fallback
- Saved to `Movies/X100Zoom`

## Build
Requires Android Studio with Android SDK 36 and JDK 17.
AGP 9.3.0 / Gradle 9.5.0 are compatible according to current Android documentation.

Open the project, let Gradle sync, then Build > Build APK(s).

## GitHub one-click build
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`.
Push the project to GitHub, run **Build X100 Zoom APK**, then download the `X100ZoomCamera-debug` artifact.
