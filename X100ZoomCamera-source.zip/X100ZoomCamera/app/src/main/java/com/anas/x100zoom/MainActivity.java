package com.anas.x100zoom;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileDescriptor;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Experimental Vivo X100 4K60 zoom camera.
 *
 * Goal: bypass the stock Camera app's 10x UI policy if the Camera2/Vivo HAL itself
 * exposes a larger zoom range during a 4K60 recording session.
 *
 * This build intentionally does NOT fake 30x by upscaling. If Camera2 reports only
 * 10x at runtime, the UI says so. A later GL encoder path can add post-crop 10-30x.
 */
public class MainActivity extends Activity {
    private static final int REQ_PERMS = 77;
    private static final Size UHD = new Size(3840, 2160);
    private static final int TARGET_FPS = 60;
    private static final int VIDEO_BITRATE = 100_000_000;

    private TextureView textureView;
    private TextView infoView;
    private TextView zoomView;
    private Button recordButton;
    private SeekBar zoomBar;

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraManager cameraManager;
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private CaptureRequest.Builder repeatingBuilder;
    private CameraCharacteristics characteristics;
    private String cameraId;

    private MediaRecorder recorder;
    private boolean recording = false;
    private Uri outputUri;
    private android.os.ParcelFileDescriptor outputPfd;

    private float requestedZoom = 1.0f;
    private float apiMinZoom = 1.0f;
    private float apiMaxZoom = 1.0f;
    private boolean supports4k60 = false;
    private boolean supportsHevc = false;
    private int sensorOrientation = 90;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        buildUi();

        if (hasPermissions()) {
            startCameraThread();
            if (textureView.isAvailable()) openCamera();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, REQ_PERMS);
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        textureView = new TextureView(this);
        textureView.setSurfaceTextureListener(textureListener);
        root.addView(textureView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        infoView = new TextView(this);
        infoView.setTextColor(Color.WHITE);
        infoView.setTextSize(12f);
        infoView.setBackgroundColor(0x88000000);
        infoView.setPadding(18, 12, 18, 12);
        FrameLayout.LayoutParams infoLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        infoLp.gravity = Gravity.TOP;
        root.addView(infoView, infoLp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(18, 12, 18, 26);
        bottom.setBackgroundColor(0x99000000);

        zoomView = new TextView(this);
        zoomView.setTextColor(Color.WHITE);
        zoomView.setTextSize(18f);
        zoomView.setGravity(Gravity.CENTER);
        zoomView.setText("1.0×");
        bottom.addView(zoomView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        zoomBar = new SeekBar(this);
        zoomBar.setMax(290); // 1.0x .. 30.0x in 0.1 increments
        zoomBar.setProgress(0);
        zoomBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                requestedZoom = 1.0f + progress / 10.0f;
                applyZoom();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        bottom.addView(zoomBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout presets = new LinearLayout(this);
        presets.setGravity(Gravity.CENTER);
        float[] vals = {1f, 5f, 10f, 20f, 30f};
        for (float value : vals) {
            Button b = new Button(this);
            b.setText(String.format(Locale.US, "%.0f×", value));
            b.setTextSize(12f);
            b.setOnClickListener(v -> setZoom(value));
            presets.addView(b, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
        bottom.addView(presets, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        recordButton = new Button(this);
        recordButton.setText("REC 4K60");
        recordButton.setOnClickListener(v -> {
            if (recording) stopRecording(); else startRecording();
        });
        bottom.addView(recordButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        bottomLp.gravity = Gravity.BOTTOM;
        root.addView(bottom, bottomLp);
        setContentView(root);
    }

    private boolean hasPermissions() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMS && hasPermissions()) {
            startCameraThread();
            if (textureView.isAvailable()) openCamera();
        } else {
            Toast.makeText(this, "Camera and microphone permissions are required.", Toast.LENGTH_LONG).show();
        }
    }

    private void startCameraThread() {
        if (cameraThread != null) return;
        cameraThread = new HandlerThread("X100Camera");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
    }

    private final TextureView.SurfaceTextureListener textureListener = new TextureView.SurfaceTextureListener() {
        @Override public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            if (hasPermissions()) {
                startCameraThread();
                openCamera();
            }
        }
        @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {}
        @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { return true; }
        @Override public void onSurfaceTextureUpdated(SurfaceTexture surface) {}
    };

    private void openCamera() {
        if (cameraDevice != null || cameraHandler == null) return;
        try {
            cameraId = chooseRearCamera();
            if (cameraId == null) {
                toast("No suitable rear camera found.");
                return;
            }
            characteristics = cameraManager.getCameraCharacteristics(cameraId);
            Integer orient = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
            if (orient != null) sensorOrientation = orient;
            inspectCapabilities();
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
            cameraManager.openCamera(cameraId, cameraStateCallback, cameraHandler);
        } catch (Exception e) {
            showError("Open camera: " + e.getMessage());
        }
    }

    private String chooseRearCamera() throws CameraAccessException {
        String bestId = null;
        float bestScore = -1f;
        for (String id : cameraManager.getCameraIdList()) {
            CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;

            float score = 0f;
            Float maxDig = c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            if (maxDig != null) score += Math.min(maxDig, 100f);
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                Range<Float> zr = c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
                if (zr != null) score += Math.min(zr.getUpper(), 100f) * 2f;
            }
            int[] caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
            if (caps != null) {
                for (int cap : caps) {
                    if (cap == CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA) {
                        score += 1000f;
                    }
                }
            }
            StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null && containsSize(map.getOutputSizes(MediaRecorder.class), UHD)) score += 500f;
            if (score > bestScore) {
                bestScore = score;
                bestId = id;
            }
        }
        return bestId;
    }

    private void inspectCapabilities() {
        apiMinZoom = 1f;
        apiMaxZoom = 1f;
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            Range<Float> range = characteristics.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
            if (range != null) {
                apiMinZoom = range.getLower();
                apiMaxZoom = range.getUpper();
            }
        }
        if (apiMaxZoom <= 1f) {
            Float max = characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            if (max != null) apiMaxZoom = max;
        }

        supports4k60 = has4k60(characteristics);
        supportsHevc = hasEncoder("video/hevc");

        StringBuilder sb = new StringBuilder();
        sb.append("X100 DIRECT-HAL TEST\n");
        sb.append("Camera ID: ").append(cameraId).append("\n");
        sb.append("4K60 advertised: ").append(supports4k60 ? "YES" : "NO").append("\n");
        sb.append("Camera2 zoom: ").append(String.format(Locale.US, "%.2f×–%.2f×", apiMinZoom, apiMaxZoom)).append("\n");
        sb.append("Codec: ").append(supportsHevc ? "HEVC/H.265" : "H.264").append("\n");

        int[] eis = characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
        sb.append("EIS: ").append(eis != null ? Arrays.toString(eis) : "unknown").append("\n");
        int[] ois = characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION);
        sb.append("OIS: ").append(ois != null ? Arrays.toString(ois) : "unknown").append("\n");
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            Set<String> physical = characteristics.getPhysicalCameraIds();
            sb.append("Physical cameras: ").append(physical.isEmpty() ? "not exposed" : physical.toString()).append("\n");
        }
        sb.append(apiMaxZoom >= 30f ? "30× direct path AVAILABLE" : "30× direct path NOT YET proven");
        runOnUiThread(() -> infoView.setText(sb.toString()));
    }

    private boolean has4k60(CameraCharacteristics c) {
        StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (map == null || !containsSize(map.getOutputSizes(MediaRecorder.class), UHD)) return false;
        Range<Integer>[] fps = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
        if (fps == null) return false;
        for (Range<Integer> r : fps) {
            if (r.getLower() <= TARGET_FPS && r.getUpper() >= TARGET_FPS) return true;
        }
        // Some OEMs only advertise 4K60 through a session/vendor path; allow recording attempt.
        return true;
    }

    private boolean containsSize(Size[] sizes, Size wanted) {
        if (sizes == null) return false;
        for (Size s : sizes) if (s.equals(wanted)) return true;
        return false;
    }

    private boolean hasEncoder(String mime) {
        MediaCodecList list = new MediaCodecList(MediaCodecList.ALL_CODECS);
        for (MediaCodecInfo info : list.getCodecInfos()) {
            if (!info.isEncoder()) continue;
            for (String type : info.getSupportedTypes()) {
                if (type.equalsIgnoreCase(mime)) return true;
            }
        }
        return false;
    }

    private final CameraDevice.StateCallback cameraStateCallback = new CameraDevice.StateCallback() {
        @Override public void onOpened(CameraDevice camera) {
            cameraDevice = camera;
            startPreview();
        }
        @Override public void onDisconnected(CameraDevice camera) {
            camera.close(); cameraDevice = null;
        }
        @Override public void onError(CameraDevice camera, int error) {
            camera.close(); cameraDevice = null;
            showError("Camera error " + error);
        }
    };

    private void startPreview() {
        if (cameraDevice == null || !textureView.isAvailable()) return;
        try {
            closeSession();
            SurfaceTexture st = textureView.getSurfaceTexture();
            if (st == null) return;
            st.setDefaultBufferSize(1920, 1080);
            Surface preview = new Surface(st);
            repeatingBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            repeatingBuilder.addTarget(preview);
            configureCommonRequest(repeatingBuilder, false);
            cameraDevice.createCaptureSession(Collections.singletonList(preview), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession session) {
                    if (cameraDevice == null) return;
                    captureSession = session;
                    try {
                        captureSession.setRepeatingRequest(repeatingBuilder.build(), null, cameraHandler);
                        applyZoom();
                    } catch (CameraAccessException e) {
                        showError("Preview: " + e.getMessage());
                    }
                }
                @Override public void onConfigureFailed(CameraCaptureSession session) {
                    showError("Preview session configuration failed.");
                }
            }, cameraHandler);
        } catch (Exception e) {
            showError("Preview setup: " + e.getMessage());
        }
    }

    private void startRecording() {
        if (cameraDevice == null || recording) return;
        if (!supports4k60) {
            toast("The selected Camera2 device does not clearly advertise 4K60; trying anyway.");
        }
        try {
            closeSession();
            prepareRecorder();

            SurfaceTexture st = textureView.getSurfaceTexture();
            if (st == null) throw new IllegalStateException("Preview surface unavailable");
            st.setDefaultBufferSize(1920, 1080);
            Surface preview = new Surface(st);
            Surface recordSurface = recorder.getSurface();

            repeatingBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            repeatingBuilder.addTarget(preview);
            repeatingBuilder.addTarget(recordSurface);
            configureCommonRequest(repeatingBuilder, true);

            List<Surface> outputs = new ArrayList<>();
            outputs.add(preview);
            outputs.add(recordSurface);
            cameraDevice.createCaptureSession(outputs, new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession session) {
                    captureSession = session;
                    try {
                        captureSession.setRepeatingRequest(repeatingBuilder.build(), null, cameraHandler);
                        recorder.start();
                        recording = true;
                        runOnUiThread(() -> recordButton.setText("STOP"));
                    } catch (Exception e) {
                        showError("Start record: " + e.getMessage());
                        safeResetRecorder();
                        startPreview();
                    }
                }
                @Override public void onConfigureFailed(CameraCaptureSession session) {
                    showError("4K60 recording session was rejected by the camera HAL.");
                    safeResetRecorder();
                    startPreview();
                }
            }, cameraHandler);
        } catch (Exception e) {
            showError("Record setup: " + e.getMessage());
            safeResetRecorder();
            startPreview();
        }
    }

    private void prepareRecorder() throws IOException {
        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setVideoEncoder(supportsHevc ? MediaRecorder.VideoEncoder.HEVC : MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(UHD.getWidth(), UHD.getHeight());
        recorder.setVideoFrameRate(TARGET_FPS);
        recorder.setVideoEncodingBitRate(VIDEO_BITRATE);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        recorder.setAudioSamplingRate(48_000);
        recorder.setAudioEncodingBitRate(192_000);
        recorder.setOrientationHint(computeOrientationHint());

        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, "X100_4K60_" + System.currentTimeMillis() + ".mp4");
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/X100Zoom");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        ContentResolver resolver = getContentResolver();
        outputUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (outputUri == null) throw new IOException("Cannot create output video");
        outputPfd = resolver.openFileDescriptor(outputUri, "w");
        if (outputPfd == null) throw new IOException("Cannot open output video");
        FileDescriptor fd = outputPfd.getFileDescriptor();
        recorder.setOutputFile(fd);
        recorder.prepare();
    }

    private int computeOrientationHint() {
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        int degrees;
        switch (rotation) {
            case Surface.ROTATION_90: degrees = 90; break;
            case Surface.ROTATION_180: degrees = 180; break;
            case Surface.ROTATION_270: degrees = 270; break;
            default: degrees = 0;
        }
        return (sensorOrientation - degrees + 360) % 360;
    }

    private void configureCommonRequest(CaptureRequest.Builder b, boolean forVideo) {
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);

        if (forVideo) {
            Range<Integer> selected = choose60FpsRange();
            if (selected != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, selected);
        }
        enableBestStabilization(b);
        setZoomOnBuilder(b, requestedZoom);
    }

    private Range<Integer> choose60FpsRange() {
        Range<Integer>[] ranges = characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
        if (ranges == null) return null;
        Range<Integer> best = null;
        for (Range<Integer> r : ranges) {
            if (r.getLower() <= 60 && r.getUpper() >= 60) {
                if (best == null) best = r;
                if (r.getLower() == 60 && r.getUpper() == 60) return r;
                if (r.getLower() > best.getLower()) best = r;
            }
        }
        return best;
    }

    private void enableBestStabilization(CaptureRequest.Builder b) {
        int[] eisModes = characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
        boolean eisOn = contains(eisModes, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON);
        boolean previewStab = android.os.Build.VERSION.SDK_INT >= 33 &&
                contains(eisModes, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION);
        if (previewStab) {
            b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION);
            return;
        }
        if (eisOn) {
            b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON);
            return;
        }
        int[] oisModes = characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION);
        if (contains(oisModes, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)) {
            b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON);
        }
    }

    private boolean contains(int[] values, int wanted) {
        if (values == null) return false;
        for (int v : values) if (v == wanted) return true;
        return false;
    }

    private void setZoom(float value) {
        requestedZoom = Math.max(1f, Math.min(30f, value));
        zoomBar.setProgress(Math.round((requestedZoom - 1f) * 10f));
        applyZoom();
    }

    private void applyZoom() {
        final float effective = Math.max(apiMinZoom, Math.min(requestedZoom, apiMaxZoom));
        runOnUiThread(() -> {
            if (requestedZoom <= apiMaxZoom + 0.001f) {
                zoomView.setText(String.format(Locale.US, "%.1f×  DIRECT", requestedZoom));
            } else {
                zoomView.setText(String.format(Locale.US, "%.1f× requested · HAL %.1f×", requestedZoom, effective));
            }
        });
        if (repeatingBuilder == null || captureSession == null || characteristics == null) return;
        try {
            setZoomOnBuilder(repeatingBuilder, requestedZoom);
            captureSession.setRepeatingRequest(repeatingBuilder.build(), null, cameraHandler);
        } catch (Exception e) {
            showError("Zoom rejected: " + e.getMessage());
        }
    }

    private void setZoomOnBuilder(CaptureRequest.Builder b, float requested) {
        float z = Math.max(apiMinZoom, Math.min(requested, apiMaxZoom));
        if (android.os.Build.VERSION.SDK_INT >= 30 &&
                characteristics.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) != null) {
            b.set(CaptureRequest.CONTROL_ZOOM_RATIO, z);
            return;
        }
        // Fallback for pre-API-30 semantics: SCALER_CROP_REGION.
        android.graphics.Rect active = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
        if (active == null || z <= 1f) return;
        int cropW = Math.max(2, Math.round(active.width() / z));
        int cropH = Math.max(2, Math.round(active.height() / z));
        int left = active.centerX() - cropW / 2;
        int top = active.centerY() - cropH / 2;
        android.graphics.Rect crop = new android.graphics.Rect(left, top, left + cropW, top + cropH);
        b.set(CaptureRequest.SCALER_CROP_REGION, crop);
    }

    private void stopRecording() {
        if (!recording) return;
        try {
            if (captureSession != null) {
                try { captureSession.stopRepeating(); } catch (Exception ignored) {}
                try { captureSession.abortCaptures(); } catch (Exception ignored) {}
            }
            recorder.stop();
            finalizeOutput(true);
            toast("Saved to Movies/X100Zoom");
        } catch (RuntimeException e) {
            // MediaRecorder can throw if no complete frame was written.
            finalizeOutput(false);
            showError("Recording failed: " + e.getMessage());
        } finally {
            recording = false;
            runOnUiThread(() -> recordButton.setText("REC 4K60"));
            safeResetRecorder();
            startPreview();
        }
    }

    private void finalizeOutput(boolean keep) {
        try {
            if (outputPfd != null) outputPfd.close();
        } catch (IOException ignored) {}
        outputPfd = null;
        if (outputUri != null) {
            if (keep) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Video.Media.IS_PENDING, 0);
                getContentResolver().update(outputUri, done, null, null);
            } else {
                getContentResolver().delete(outputUri, null, null);
            }
        }
        outputUri = null;
    }

    private void safeResetRecorder() {
        if (recorder != null) {
            try { recorder.reset(); } catch (Exception ignored) {}
            try { recorder.release(); } catch (Exception ignored) {}
            recorder = null;
        }
        try {
            if (outputPfd != null) outputPfd.close();
        } catch (IOException ignored) {}
        outputPfd = null;
    }

    private void closeSession() {
        if (captureSession != null) {
            try { captureSession.close(); } catch (Exception ignored) {}
            captureSession = null;
        }
        repeatingBuilder = null;
    }

    private void closeCamera() {
        if (recording) stopRecording();
        closeSession();
        if (cameraDevice != null) {
            cameraDevice.close();
            cameraDevice = null;
        }
        safeResetRecorder();
    }

    private void stopCameraThread() {
        if (cameraThread != null) {
            cameraThread.quitSafely();
            try { cameraThread.join(); } catch (InterruptedException ignored) {}
            cameraThread = null;
            cameraHandler = null;
        }
    }

    private void toast(String s) {
        runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_LONG).show());
    }

    private void showError(String s) {
        runOnUiThread(() -> {
            Toast.makeText(this, s, Toast.LENGTH_LONG).show();
            String old = infoView.getText().toString();
            infoView.setText(old + "\nERROR: " + s);
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (hasPermissions()) {
            startCameraThread();
            if (textureView != null && textureView.isAvailable()) openCamera();
        }
    }

    @Override protected void onPause() {
        closeCamera();
        stopCameraThread();
        super.onPause();
    }
}
